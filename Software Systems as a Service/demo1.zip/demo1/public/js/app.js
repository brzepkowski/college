// Declares the initial angular module "meanMapApp". Module grabs other controllers and services.
var app = angular.module('soa', ['addCtrl', 'geolocation', 'gservice']);
